from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search')
def search():
    query = request.args.get('q', '')
    conn = get_db_connection()
    cursor = conn.cursor()
    
    sql_query = "SELECT * FROM users WHERE name = '%s'" % query
    cursor.execute(sql_query)
    
    results = cursor.fetchall()
    conn.close()
    return str(results)

if __name__ == '__main__':
    app.run(debug=True)
