# Class Project: Flask App

This repository was created as part of a student project for a web application course. The goal of the project is to build a simple Flask application that interacts with a SQLite database.

## Project Overview

The application includes a basic search functionality that queries a database of users. It serves as a simple example of using Flask with a database.

## How to Run the Project

1. Install the dependencies:
   ```bash
   pip install -r requirements.txt
